package io.healthresetplan.modules.report.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;

import java.time.LocalDateTime;

@TableName("health_report")
public class HealthReport {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String userId;
    private String clientId;
    private String imageOssKey;
    private String imageWrappedDek;
    private String imageDekIv;
    private String imageDekTag;
    private String ocrTextCipher;
    private String ocrTextIv;
    private String ocrTextTag;
    private String structuredCipher;
    private String structuredIv;
    private String structuredTag;
    private String summaryCipher;
    private String summaryIv;
    private String summaryTag;
    private String alg;
    private LocalDateTime reportTime;
    private String deviceId;
    private LocalDateTime clientUpdatedAt;
    private LocalDateTime serverUpdatedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @TableLogic(value = "NULL", delval = "NOW(3)")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private LocalDateTime deletedAt;

    @Version
    private Long version;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public String getImageOssKey() { return imageOssKey; }
    public void setImageOssKey(String imageOssKey) { this.imageOssKey = imageOssKey; }

    public String getImageWrappedDek() { return imageWrappedDek; }
    public void setImageWrappedDek(String imageWrappedDek) { this.imageWrappedDek = imageWrappedDek; }

    public String getImageDekIv() { return imageDekIv; }
    public void setImageDekIv(String imageDekIv) { this.imageDekIv = imageDekIv; }

    public String getImageDekTag() { return imageDekTag; }
    public void setImageDekTag(String imageDekTag) { this.imageDekTag = imageDekTag; }

    public String getOcrTextCipher() { return ocrTextCipher; }
    public void setOcrTextCipher(String ocrTextCipher) { this.ocrTextCipher = ocrTextCipher; }

    public String getOcrTextIv() { return ocrTextIv; }
    public void setOcrTextIv(String ocrTextIv) { this.ocrTextIv = ocrTextIv; }

    public String getOcrTextTag() { return ocrTextTag; }
    public void setOcrTextTag(String ocrTextTag) { this.ocrTextTag = ocrTextTag; }

    public String getStructuredCipher() { return structuredCipher; }
    public void setStructuredCipher(String structuredCipher) { this.structuredCipher = structuredCipher; }

    public String getStructuredIv() { return structuredIv; }
    public void setStructuredIv(String structuredIv) { this.structuredIv = structuredIv; }

    public String getStructuredTag() { return structuredTag; }
    public void setStructuredTag(String structuredTag) { this.structuredTag = structuredTag; }

    public String getSummaryCipher() { return summaryCipher; }
    public void setSummaryCipher(String summaryCipher) { this.summaryCipher = summaryCipher; }

    public String getSummaryIv() { return summaryIv; }
    public void setSummaryIv(String summaryIv) { this.summaryIv = summaryIv; }

    public String getSummaryTag() { return summaryTag; }
    public void setSummaryTag(String summaryTag) { this.summaryTag = summaryTag; }

    public String getAlg() { return alg; }
    public void setAlg(String alg) { this.alg = alg; }

    public LocalDateTime getReportTime() { return reportTime; }
    public void setReportTime(LocalDateTime reportTime) { this.reportTime = reportTime; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public LocalDateTime getClientUpdatedAt() { return clientUpdatedAt; }
    public void setClientUpdatedAt(LocalDateTime clientUpdatedAt) { this.clientUpdatedAt = clientUpdatedAt; }

    public LocalDateTime getServerUpdatedAt() { return serverUpdatedAt; }
    public void setServerUpdatedAt(LocalDateTime serverUpdatedAt) { this.serverUpdatedAt = serverUpdatedAt; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public LocalDateTime getDeletedAt() { return deletedAt; }
    public void setDeletedAt(LocalDateTime deletedAt) { this.deletedAt = deletedAt; }

    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }
}
